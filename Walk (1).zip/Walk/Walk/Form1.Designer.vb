﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IntastningAfWalkData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Datolabel = New System.Windows.Forms.Label()
        Me.FornavnLabel = New System.Windows.Forms.Label()
        Me.EfternavnLabel = New System.Windows.Forms.Label()
        Me.AntalMinutterLabel = New System.Windows.Forms.Label()
        Me.KalorierLabel = New System.Windows.Forms.Label()
        Me.KmLabel = New System.Windows.Forms.Label()
        Me.SkridtLabel = New System.Windows.Forms.Label()
        Me.DatoVærdi = New System.Windows.Forms.TextBox()
        Me.AntalMinutterVærdi = New System.Windows.Forms.TextBox()
        Me.AntalKmVærdi = New System.Windows.Forms.TextBox()
        Me.AntalSkridtVærdi = New System.Windows.Forms.TextBox()
        Me.EfternavnTekst = New System.Windows.Forms.TextBox()
        Me.FornavnTekst = New System.Windows.Forms.TextBox()
        Me.AntalKalorierVærdi = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Datolabel
        '
        Me.Datolabel.AutoSize = True
        Me.Datolabel.Location = New System.Drawing.Point(32, 53)
        Me.Datolabel.Name = "Datolabel"
        Me.Datolabel.Size = New System.Drawing.Size(30, 13)
        Me.Datolabel.TabIndex = 0
        Me.Datolabel.Text = "Dato"
        '
        'FornavnLabel
        '
        Me.FornavnLabel.AutoSize = True
        Me.FornavnLabel.Location = New System.Drawing.Point(32, 91)
        Me.FornavnLabel.Name = "FornavnLabel"
        Me.FornavnLabel.Size = New System.Drawing.Size(46, 13)
        Me.FornavnLabel.TabIndex = 1
        Me.FornavnLabel.Text = "Fornavn"
        '
        'EfternavnLabel
        '
        Me.EfternavnLabel.AutoSize = True
        Me.EfternavnLabel.Location = New System.Drawing.Point(32, 126)
        Me.EfternavnLabel.Name = "EfternavnLabel"
        Me.EfternavnLabel.Size = New System.Drawing.Size(53, 13)
        Me.EfternavnLabel.TabIndex = 2
        Me.EfternavnLabel.Text = "Efternavn"
        '
        'AntalMinutterLabel
        '
        Me.AntalMinutterLabel.AutoSize = True
        Me.AntalMinutterLabel.Location = New System.Drawing.Point(32, 219)
        Me.AntalMinutterLabel.Name = "AntalMinutterLabel"
        Me.AntalMinutterLabel.Size = New System.Drawing.Size(71, 13)
        Me.AntalMinutterLabel.TabIndex = 3
        Me.AntalMinutterLabel.Text = "Antal minutter"
        '
        'KalorierLabel
        '
        Me.KalorierLabel.AutoSize = True
        Me.KalorierLabel.Location = New System.Drawing.Point(32, 254)
        Me.KalorierLabel.Name = "KalorierLabel"
        Me.KalorierLabel.Size = New System.Drawing.Size(68, 13)
        Me.KalorierLabel.TabIndex = 4
        Me.KalorierLabel.Text = "Antal kalorier"
        '
        'KmLabel
        '
        Me.KmLabel.AutoSize = True
        Me.KmLabel.Location = New System.Drawing.Point(32, 189)
        Me.KmLabel.Name = "KmLabel"
        Me.KmLabel.Size = New System.Drawing.Size(48, 13)
        Me.KmLabel.TabIndex = 5
        Me.KmLabel.Text = "Antal km"
        '
        'SkridtLabel
        '
        Me.SkridtLabel.AutoSize = True
        Me.SkridtLabel.Location = New System.Drawing.Point(32, 160)
        Me.SkridtLabel.Name = "SkridtLabel"
        Me.SkridtLabel.Size = New System.Drawing.Size(59, 13)
        Me.SkridtLabel.TabIndex = 6
        Me.SkridtLabel.Text = "Antal skridt"
        '
        'DatoVærdi
        '
        Me.DatoVærdi.Location = New System.Drawing.Point(159, 45)
        Me.DatoVærdi.Name = "DatoVærdi"
        Me.DatoVærdi.Size = New System.Drawing.Size(100, 20)
        Me.DatoVærdi.TabIndex = 7
        '
        'AntalMinutterVærdi
        '
        Me.AntalMinutterVærdi.Location = New System.Drawing.Point(159, 216)
        Me.AntalMinutterVærdi.Name = "AntalMinutterVærdi"
        Me.AntalMinutterVærdi.Size = New System.Drawing.Size(100, 20)
        Me.AntalMinutterVærdi.TabIndex = 8
        '
        'AntalKmVærdi
        '
        Me.AntalKmVærdi.Location = New System.Drawing.Point(159, 186)
        Me.AntalKmVærdi.Name = "AntalKmVærdi"
        Me.AntalKmVærdi.Size = New System.Drawing.Size(100, 20)
        Me.AntalKmVærdi.TabIndex = 9
        '
        'AntalSkridtVærdi
        '
        Me.AntalSkridtVærdi.Location = New System.Drawing.Point(159, 160)
        Me.AntalSkridtVærdi.Name = "AntalSkridtVærdi"
        Me.AntalSkridtVærdi.Size = New System.Drawing.Size(100, 20)
        Me.AntalSkridtVærdi.TabIndex = 10
        '
        'EfternavnTekst
        '
        Me.EfternavnTekst.Location = New System.Drawing.Point(159, 126)
        Me.EfternavnTekst.Name = "EfternavnTekst"
        Me.EfternavnTekst.Size = New System.Drawing.Size(100, 20)
        Me.EfternavnTekst.TabIndex = 11
        '
        'FornavnTekst
        '
        Me.FornavnTekst.Location = New System.Drawing.Point(159, 91)
        Me.FornavnTekst.Name = "FornavnTekst"
        Me.FornavnTekst.Size = New System.Drawing.Size(100, 20)
        Me.FornavnTekst.TabIndex = 12
        '
        'AntalKalorierVærdi
        '
        Me.AntalKalorierVærdi.Location = New System.Drawing.Point(159, 254)
        Me.AntalKalorierVærdi.Name = "AntalKalorierVærdi"
        Me.AntalKalorierVærdi.Size = New System.Drawing.Size(100, 20)
        Me.AntalKalorierVærdi.TabIndex = 13
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(35, 361)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Insert Data"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'IntastningAfWalkData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.AntalKalorierVærdi)
        Me.Controls.Add(Me.FornavnTekst)
        Me.Controls.Add(Me.EfternavnTekst)
        Me.Controls.Add(Me.AntalSkridtVærdi)
        Me.Controls.Add(Me.AntalKmVærdi)
        Me.Controls.Add(Me.AntalMinutterVærdi)
        Me.Controls.Add(Me.DatoVærdi)
        Me.Controls.Add(Me.SkridtLabel)
        Me.Controls.Add(Me.KmLabel)
        Me.Controls.Add(Me.KalorierLabel)
        Me.Controls.Add(Me.AntalMinutterLabel)
        Me.Controls.Add(Me.EfternavnLabel)
        Me.Controls.Add(Me.FornavnLabel)
        Me.Controls.Add(Me.Datolabel)
        Me.Name = "IntastningAfWalkData"
        Me.Text = "Intastning af Walk data"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Datolabel As Label
    Friend WithEvents FornavnLabel As Label
    Friend WithEvents EfternavnLabel As Label
    Friend WithEvents AntalMinutterLabel As Label
    Friend WithEvents KalorierLabel As Label
    Friend WithEvents KmLabel As Label
    Friend WithEvents SkridtLabel As Label
    Friend WithEvents DatoVærdi As TextBox
    Friend WithEvents AntalMinutterVærdi As TextBox
    Friend WithEvents AntalKmVærdi As TextBox
    Friend WithEvents AntalSkridtVærdi As TextBox
    Friend WithEvents EfternavnTekst As TextBox
    Friend WithEvents FornavnTekst As TextBox
    Friend WithEvents AntalKalorierVærdi As TextBox
    Friend WithEvents Button1 As Button
End Class
