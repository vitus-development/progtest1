﻿Public Class IntastningAfWalkData
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sqlconnection = New sqlconnection("Data Source= Vitus; Inetial catalog= Walk; Integrated security = True;)
            connection.open();
dim adddata as sqlcommand= New sqlcommand 
("insert into Walk (Name,name2,Value1, Value2) values ('"& textbox1.text&"', '"& textbox2.text&"', '"& textbox3.text&"','"& textbox4.text&"')connection);
adddate.executenonquiry();
connection.close();
    End Sub
End Class
