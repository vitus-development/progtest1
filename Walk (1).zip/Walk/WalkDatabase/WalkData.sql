﻿CREATE TABLE [dbo].[WalkData]
(
	[Id] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
	[Dato] DATETIME NOT NULL, 
    [Fornavn] TEXT NOT NULL, 
    [Efternavn] TEXT NOT NULL, 
    [Skridt] FLOAT NOT NULL DEFAULT 0, 
    [Km] FLOAT NOT NULL DEFAULT 0, 
    [Minutter] FLOAT NOT NULL DEFAULT 0, 
    [Kalorier] FLOAT NOT NULL DEFAULT 0, 
    [Fk_Person_ID] BIGINT NOT NULL DEFAULT 0, 
    CONSTRAINT [FK_WalkData_PK_BrugerData] FOREIGN KEY ([Fk_Person_ID]) REFERENCES [dbo.BrugerData]([Pk_Person_ID]) 
)
